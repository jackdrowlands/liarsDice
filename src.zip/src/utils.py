import os
from typing import List, Optional, Union, Dict, Any, Tuple

def print_intro() -> None:
    """Print the introduction message for the game"""
    print("=" * 70)
    print("Welcome to Liar's Dice OpenRouter Tournament!")
    print("=" * 70)
    print("\nIn this game, each player has dice that only they can see.")
    print("Players take turns making bids about how many dice of a certain value exist among all players.")
    print("Each bid must be higher than the previous one (either more dice, or same number but higher value).")
    print("When a player thinks the previous bid is a lie, they can call 'Liar'.")
    print("The loser of each round loses one die. The last player with dice is the winner!")
    
    try:
        import requests
        OPENROUTER_AVAILABLE = True
    except ImportError:
        OPENROUTER_AVAILABLE = False
        
    if OPENROUTER_AVAILABLE:
        print("\nOpenRouter integration is AVAILABLE!")
        print("Game Modes Available:")
        print("1. Human Players Only - Play with friends")
        print("2. Mixed Game - Play with a mix of human and AI players") 
        print("3. AI vs AI - Watch different AI models compete against each other")
        
        print("\n🤖 MODEL VS MODEL FEATURE 🤖")
        print("- Pit different AI models against each other")
        print("- Run tournaments to find the best Liar's Dice AI")
        print("- See detailed statistics and performance metrics")
        
        print("\nModels Available Through OpenRouter:")
        print("- Claude 3 (Anthropic)")
        print("- GPT-4 and GPT-4o (OpenAI)")
        print("- Gemini (Google)")
        print("- Mistral, Llama, Command-R, and many others")
        print("- Access to 50+ different models through a single API")
        
        print("\nEach model has its own 'personality' and strategic approach")
        print("Auto mode available to watch games without interruption")
    else:
        print("\nOpenRouter integration is NOT available.")
        print("To enable AI players, install the required package:")
        print("- pip install requests")
        print("\nYou'll also need an OpenRouter API key from openrouter.ai")
    
    print("\nLet's get started!\n")
    print("=" * 70)


def print_main_menu() -> str:
    """Print the main menu options and get user selection"""
    print("\n" + "=" * 70)
    print("LIARS DICE MAIN MENU")
    print("=" * 70)
    print("1. Play a single game")
    print("2. Run a model tournament")
    print("3. Load a saved game")
    print("4. Exit")
    return input("\nSelect an option (1-4): ").strip()
    
def find_saved_games() -> List[str]:
    """Find all saved game files in the current directory"""
    import glob
    saves: List[str] = glob.glob("liars_dice_save_*.json")
    saves.sort(reverse=True)  # Most recent first
    return saves
    
def select_saved_game() -> Optional[str]:
    """Let user select a saved game from available saves"""
    saves: List[str] = find_saved_games()
    
    if not saves:
        print("No saved games found.")
        return None
    
    print("\nAvailable saved games:")
    for i, save in enumerate(saves):
        print(f"{i+1}. {save}")
    
    try:
        choice: int = int(input("\nSelect a game to load (number) or 0 to cancel: "))
        if choice == 0:
            return None
        elif 1 <= choice <= len(saves):
            return saves[choice-1]
        else:
            print("Invalid selection.")
            return None
    except ValueError:
        print("Invalid input.")
        return None
        
# Add any other utility functions here with type hints

def validate_bid(bid: Tuple[int, int], last_bid: Optional[Tuple[int, int]] = None) -> bool:
    """
    Validate if a bid is legal according to game rules
    
    Args:
        bid: A tuple of (quantity, face value)
        last_bid: The previous bid to compare against (if any)
        
    Returns:
        True if the bid is valid, False otherwise
    """
    quantity, face = bid
    
    # Basic validation
    if quantity < 1 or face < 1 or face > 6:
        return False
        
    # If there's no previous bid, any valid bid is acceptable
    if not last_bid:
        return True
        
    # Check against previous bid
    last_quantity, last_face = last_bid
    
    # Higher quantity always wins
    if quantity > last_quantity:
        return True
        
    # Same quantity but higher face
    if quantity == last_quantity and face > last_face:
        return True
        
    # Otherwise, bid is not higher
    return False

def format_time(seconds: float) -> str:
    """Format seconds into a readable time string"""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = seconds % 60
        return f"{minutes}m {secs:.1f}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"
